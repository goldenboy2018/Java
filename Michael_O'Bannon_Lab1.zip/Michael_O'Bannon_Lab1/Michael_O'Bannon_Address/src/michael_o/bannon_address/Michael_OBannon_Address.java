/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package michael_o.bannon_address;

/**
 *
 * @author Moraldus
 */
public class Michael_OBannon_Address {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Michael O'Bannon");
        System.out.println("17612 Throckley Ave");
        System.out.println("Cleveland Ohio, 44128");        
    }
    
}
